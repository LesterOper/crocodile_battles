﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using UnityEngine;

namespace SimpleSQL
{
    static public class RuntimeHelper
    {
        static public bool CreateFileFromEmbeddedResource(string resourcePath, string filePath)
        {
            if (!File.Exists(filePath))
            {
                Stream myStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourcePath);
                if (myStream != null)
                {
                    try
                    {
                        File.WriteAllBytes(filePath, ReadToEnd(myStream));
                        myStream.Close();
                    }
                    catch (Exception ex)
                    {
                        if (myStream != null)
                        {
                            myStream.Close();
                        }

                        Debug.LogError("Could not write resource to path: " + filePath + " " + ex.Message);
                    }
                }
                else
                {
                    Debug.LogError("Missing Dll resource: " + resourcePath);
                    return false;
                }
            }

            return true;
        }


        static private byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }

        //static public void LoadAssemblyFromEmbeddedResource(string resourcePath)
        //{
        //    try
        //    {
        //        Debug.Log(Assembly.GetCallingAssembly());
        //        Debug.Log(Assembly.GetCallingAssembly().GetManifestResourceStream(resourcePath));

        //        using (Stream input = Assembly.GetCallingAssembly().GetManifestResourceStream(resourcePath))
        //        {
        //            Assembly.Load(StreamToBytes(input));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.LogError("Error dynamically loading dll: " + resourcePath + " " + ex);
        //    }
        //}

        static private byte[] StreamToBytes(Stream input)
        {
            int capacity = input.CanSeek ? (int)input.Length : 0;
            using (MemoryStream output = new MemoryStream(capacity))
            {
                int readLength;
                byte[] buffer = new byte[4096];

                do
                {
                    readLength = input.Read(buffer, 0, buffer.Length); // had to change to buffer.Length
                    output.Write(buffer, 0, readLength);
                }
                while (readLength != 0);

                return output.ToArray();
            }
        }

    }
}
